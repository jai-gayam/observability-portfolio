# Placeholders

Replace these placeholders throughout the repo:

- `<ORG>` – your org/team identifier
- `<INDEX>` – your Splunk index
- `<SOURCETYPE>` – your Splunk sourcetype
- `<AWS_ACCOUNT_ID>` – AWS account id
- `<S3_BUCKET>` – archive bucket name
- `<VPC_ID>` – VPC identifier
